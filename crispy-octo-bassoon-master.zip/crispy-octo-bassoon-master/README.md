# crispy-octo-bassoon
Software Dev 2019 Summer group project

This is a beta travel site, where you input your desired prefrences and our data base will recommend places that you should visit.
You can register an account, and login, search for flights on KAYAK.
